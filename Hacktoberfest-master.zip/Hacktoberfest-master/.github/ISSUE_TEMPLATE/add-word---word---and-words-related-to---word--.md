---
name: Add word "[Word]" and additional words related to "[Word]"
about: Adding multiple words related to theme

---

- [ ] Word1
- [ ] Word2
- [ ] Word3
- [ ] Word4

Refer [CONTRIBUTING.md](https://github.com/Showndarya/Hacktoberfest/blob/master/CONTRIBUTING.md) for more details on how to contribute.

Comment the words you'll be adding if you're are working on this issue to avoid conflicts.
Add reference to this issue i.e Issue # in your pull request description.
