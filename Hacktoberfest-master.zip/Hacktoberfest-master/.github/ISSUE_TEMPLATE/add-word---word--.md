---
name: Add word "[Word]"
about: Adding specific words

---

Add all the definitions of `[Word]` in a file named `[Word].json` in folder `[First-Letter]`


Refer [CONTRIBUTING.md](https://github.com/Showndarya/Hacktoberfest/blob/master/CONTRIBUTING.md) for more details on how to contribute.

Comment the words you'll be adding if you're are working on this issue to avoid conflicts.
Add reference to this issue i.e Issue # in your pull request description.
