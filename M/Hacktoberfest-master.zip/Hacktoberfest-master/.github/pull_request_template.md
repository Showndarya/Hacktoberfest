The Pull Request resolves Issue #[Issue-Number]

Description:
A brief description about the addition or edits made.

Notes: Delete all the text including this!
* The `#[Issue-Number]` should be replaced with the specific Issue being referenced.
